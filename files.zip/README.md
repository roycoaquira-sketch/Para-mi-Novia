# 🌻 Girasoles

Una página web con girasoles interactivos y un mensaje de amor.
Abre `index.html` en el navegador o publícala con GitHub Pages.

## Publicarla con GitHub Pages

1. Crea un repositorio nuevo en GitHub (por ejemplo `girasoles`).
2. Sube estos archivos: `index.html`, `README.md` y `.nojekyll`.
3. Ve a **Settings → Pages**.
4. En **Source** elige **Deploy from a branch**, la rama `main` y la carpeta `/ (root)`. Guarda.
5. Espera 1 o 2 minutos. Tu link será:
   `https://TU-USUARIO.github.io/girasoles/`

## Subirla con git

```bash
git init
git add .
git commit -m "Girasoles"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/girasoles.git
git push -u origin main
```
